This is the release of JEDI API&WSCL as a testing version for Delphi 2009 (and of course older versions).
Feel free to use it...
The release was published at: http://blog.delphi-jedi.net/2008/08/30/pre-release-of-jedi-api-22-wscl-092-2/

Remark:
 These sources can be updated using a subversion client (like TortoiseSVN).

JEDI API 2.2a:
-------------
Main page : http://blog.delphi-jedi.net/jedi-api-headers/

How to setup JWA can be read here : http://blog.delphi-jedi.net/2007/12/27/how-to-setup-the-library

Report bugs to: http://homepages.codegear.com/jedi/issuetracker/main_page.php



JEDI Windows Security Code Library 0.9.2a
-----------------------------------------
Main page : http://blog.delphi-jedi.net/security-library/

How to setup JWSCL can be read here : http://blog.delphi-jedi.net/2008/03/03/how-to-setup-jwscl/

Report bugs to: http://homepages.codegear.com/jedi/issuetracker/main_page.php




Have fun!

Christian Wimmer
blog.delphi-jedi.net

