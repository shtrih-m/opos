JCL DUnit testing
=================

Requires the DUnit project ("Xtreme Unit Testing for Delphi"), available from 
http://sourceforge.net/projects/dunit/

There are two test projects:

* JclTests.dpr  - VCL project
* JclQTests.dpr - Visual CLX project (Delphi/Win32 versions >= 6, Kylix/Delphi)

You need to make directory "dunit/src/" available on the search path for 
these projects to compile.
