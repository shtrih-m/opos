OmniXMLShared requires (via GpSecurity) the JEDI Win32 API library, which you can download at http://jedi-apilib.sourceforge.net
